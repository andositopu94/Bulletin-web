package com.example.Bulletin.Implementation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BulletinImplementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BulletinImplementationApplication.class, args);
	}

}
