package com.example.Bulletin.Implementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulletinImplementationApplicationTests {

	@Test
	void contextLoads() {
	}

}
